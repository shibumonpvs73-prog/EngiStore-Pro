@echo off
title EngiStore Pro Server
color 0A
cd /d "%~dp0"

echo ================================================================
echo           ENGISTORE PRO - STARTING APPLICATION
echo ================================================================
echo.
echo Starting local application server...
start /b node server.js

echo Waiting for server to initialize...
timeout /t 2 /nobreak >nul

echo Opening EngiStore Pro in Desktop App Window...

:: Try Microsoft Edge App Mode
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:3000 --window-size=1400,900
    goto launched
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:3000 --window-size=1400,900
    goto launched
)

:: Try Google Chrome App Mode
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3000 --window-size=1400,900
    goto launched
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3000 --window-size=1400,900
    goto launched
)

:: Fallback to default browser
start http://localhost:3000

:launched
echo.
echo EngiStore Pro is running at http://localhost:3000
echo Do not close this window while using the application.
echo (Minimize this window to keep it running in the background)
echo.
pause
