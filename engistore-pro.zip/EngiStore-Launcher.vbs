Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)

' Run Start-EngiStore.bat with hidden/minimized window
WshShell.Run """" & scriptDir & "\Start-EngiStore.bat""", 1, False
